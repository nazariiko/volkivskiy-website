import React from 'react';
import { Route, Switch } from 'react-router-dom';
import styled from 'styled-components';

import Home from './pages/Home';
import Loader from './components/Loader';

const StyledApp = styled.div`
  width: 100%;
`;

const App: React.FC = () => {
  const [isLoading, setIsLoading] = React.useState(true);

  React.useEffect(() => {
    setTimeout(() => {
      setIsLoading(false);
    }, 3000);
  }, []);

  return (
    <StyledApp>
      <Loader visible={isLoading} />
      <Switch>
        <Route exact path="/" component={Home}></Route>
      </Switch>
    </StyledApp>
  );
};

export default App;
