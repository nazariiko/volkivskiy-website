import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router } from 'react-router-dom';

import { createGlobalStyle, ThemeProvider } from 'styled-components';
import { Reset } from 'styled-reset';

import { theme } from './theme';
import './scss/index.scss';

import App from './App';
import './i18n';

const GlobalStyle = createGlobalStyle`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;

  }
  body {
    background-color: ${theme.whiteBack};
    font-family: 'Open Sans Condensed', sans-serif;
    color: ${theme.whiteText};
    letter-spacing: 1px;
    font-size: 18px;
    font-style: normal;
    font-weight: 300;
    line-height: 25px;

    @media (max-width: 840px) {
      background-color: ${theme.darkBack};
    }
  }
`;

ReactDOM.render(
  <React.StrictMode>
    <Router>
      <ThemeProvider theme={theme}>
        <Reset />
        <GlobalStyle />
        <App />
      </ThemeProvider>
    </Router>
  </React.StrictMode>,
  document.getElementById('root'),
);
